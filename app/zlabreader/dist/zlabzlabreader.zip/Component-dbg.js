sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("zlab.zlabreader.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
